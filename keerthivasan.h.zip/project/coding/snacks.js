function order(){
    let t=document.getElementById("t");
    t.innerText="your order is placed";
    let v=document.getElementById("v");
    v.style.display="none";
}
function order1(){
    let t=document.getElementById("t1");
    t.innerText="your order is placed";
    let v=document.getElementById("v1");
    v.style.display="none";
}
function order2(){
    let t=document.getElementById("t2");
    t.innerText="your order is placed";
    let v=document.getElementById("v2");
    v.style.display="none";
}
function order3(){
    let t=document.getElementById("t3");
    t.innerText="your order is placed";
    let v=document.getElementById("v3");
    v.style.display="none";
}
function order4(){
    let t=document.getElementById("t4");
    t.innerText="your order is placed";
    let v=document.getElementById("v4");
    v.style.display="none";
}
function order5(){
    let t=document.getElementById("t5");
    t.innerText="your order is placed";
    let v=document.getElementById("v5");
    v.style.display="none";
}
function order6(){
    let t=document.getElementById("t6");
    t.innerText="your order is placed";
    let v=document.getElementById("v6");
    v.style.display="none";
}
function order7(){
    let t=document.getElementById("t7");
    t.innerText="your order is placed";
    let v=document.getElementById("v7");
    v.style.display="none";
}
function order8(){
    let t=document.getElementById("t8");
    t.innerText="your order is placed";
    let v=document.getElementById("v8");
    v.style.display="none";
}
function order9(){
    let t=document.getElementById("t9");
    t.innerText="your order is placed";
    let v=document.getElementById("v9");
    v.style.display="none";
}
function order10(){
    let t=document.getElementById("t10");
    t.innerText="your order is placed";
    let v=document.getElementById("v10");
    v.style.display="none";
}
function order11(){
    let t=document.getElementById("t11");
    t.innerText="your order is placed";
    let v=document.getElementById("v11");
    v.style.display="none";
}
function order12(){
    let t=document.getElementById("t12");
    t.innerText="your order is placed";
    let v=document.getElementById("v12");
    v.style.display="none";
}
function order13(){
    let t=document.getElementById("t13");
    t.innerText="your order is placed";
    let v=document.getElementById("v13");
    v.style.display="none";
}
function order14(){
    let t=document.getElementById("t14");
    t.innerText="your order is placed";
    let v=document.getElementById("v14");
    v.style.display="none";
}





