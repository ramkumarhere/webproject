function order(){
    let t=document.getElementById("t");
    t.innerText="your order is placed";
    let v=document.getElementById("v");
    v.style.display="none";
}
function order1(){
    let t=document.getElementById("t1");
    t.innerText="your order is placed";
    let v=document.getElementById("v1");
    v.style.display="none";
}